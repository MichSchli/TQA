from Mindblocks.model.value_type.old.abstract_value_type import AbstractValueType


class IndexType(AbstractValueType):

    def __init__(self):
        pass