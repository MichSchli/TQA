class IndexValueModel:

    index = None

    def assign(self, index):
        self.index = index

    def get_index(self):
        return self.index