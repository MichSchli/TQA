class UnconnectedSocketException(Exception):

    """
    Exception raised when trying to pull along an unconnected socket connection
    """