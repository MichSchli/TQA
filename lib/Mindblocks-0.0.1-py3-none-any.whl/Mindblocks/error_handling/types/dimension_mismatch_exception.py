class DimensionMismatchException(Exception):

    """
    Exception raised when mismatched dimensions are encountered
    """