class SocketNotFoundException(Exception):

    """
    Exception raised when a non-existant socket is referenced.
    """