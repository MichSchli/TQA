class ComponentTypeNotFoundException(Exception):

    """
    Exception raised when an undeclared component type is referenced.
    """