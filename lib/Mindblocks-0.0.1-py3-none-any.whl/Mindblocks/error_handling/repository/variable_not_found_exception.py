class VariableNotFoundException(Exception):

    """
    Exception raised when an undeclared variable is referenced.
    """